#!/bin/bash

var="Hello World"
 
# print it 
echo "$var"
 
# Another way of printing it
printf "%s\n" "$var"
