#!/bin/bash
echo "Hello World"

while [ $# -gt 0 ]; do
    if [[ $1 == "--"* ]]; then
        v="${1/--/}"
        declare "$v"="$2"
        shift
    fi
    shift
done

echo " '$input', '$output'"

if [ -z "$(ls -A $input)" ]; then
  echo "Data bucket is empty" >> "$output"/out.txt
else
  for entry in $input/*
  do
   echo "$entry" >> "$output"/out.txt
  done
fi




